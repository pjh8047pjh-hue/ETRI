set_property SRC_FILE_INFO {cfile:{C:/Users/user/Documents/JH/week 2/project_pmoduart/project_pmoduart.srcs/constrs_1/imports/xdc/ultra96_training_kit.xdc} rfile:../../../project_pmoduart.srcs/constrs_1/imports/xdc/ultra96_training_kit.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:34 export:INPUT save:INPUT read:READ} [current_design]
set_property PACKAGE_PIN F8   [get_ports {txd               }];  # "F8.HD_GPIO_1"
set_property src_info {type:XDC file:1 line:35 export:INPUT save:INPUT read:READ} [current_design]
set_property PACKAGE_PIN F7   [get_ports {rxd               }];  # "F7.HD_GPIO_2"
set_property src_info {type:XDC file:1 line:63 export:INPUT save:INPUT read:READ} [current_design]
set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 26]];
